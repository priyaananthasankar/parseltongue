﻿// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the MIT License. See License.txt in the project root for license information.

using System;

namespace Microsoft.Azure.WebJobs.Script
{
    public static class ErrorCodes
    {
        public const int KeyCryptographicError = 1000;
    }
}
