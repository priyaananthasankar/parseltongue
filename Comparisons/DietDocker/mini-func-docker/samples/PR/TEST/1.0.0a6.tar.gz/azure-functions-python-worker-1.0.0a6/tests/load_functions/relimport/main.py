from . import relative


def main(req) -> str:
    return relative.__name__
