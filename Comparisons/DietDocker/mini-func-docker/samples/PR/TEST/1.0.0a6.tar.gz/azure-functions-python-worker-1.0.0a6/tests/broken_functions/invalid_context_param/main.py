def main(req, context: int):
    return 'trust me, it is OK!'
