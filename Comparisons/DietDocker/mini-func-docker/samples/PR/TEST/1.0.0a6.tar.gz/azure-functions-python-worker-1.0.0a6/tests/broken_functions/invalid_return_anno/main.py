def main(req) -> int:
    return 'trust me, it is OK!'
