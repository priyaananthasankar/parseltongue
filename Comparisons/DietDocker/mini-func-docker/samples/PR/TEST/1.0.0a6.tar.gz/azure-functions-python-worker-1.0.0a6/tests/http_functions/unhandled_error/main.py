import azure.functions as azf


def main(req: azf.HttpRequest):
    1 / 0
