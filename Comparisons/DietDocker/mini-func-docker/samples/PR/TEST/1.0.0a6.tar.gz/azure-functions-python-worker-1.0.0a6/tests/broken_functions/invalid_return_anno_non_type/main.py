def main(req) -> 123:
    return 'trust me, it is OK!'
