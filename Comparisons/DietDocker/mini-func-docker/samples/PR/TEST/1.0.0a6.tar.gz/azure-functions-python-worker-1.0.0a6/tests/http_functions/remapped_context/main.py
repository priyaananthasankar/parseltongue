def main(context):
    return context.method
