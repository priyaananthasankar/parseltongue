def main(req) -> str:
    return __name__
