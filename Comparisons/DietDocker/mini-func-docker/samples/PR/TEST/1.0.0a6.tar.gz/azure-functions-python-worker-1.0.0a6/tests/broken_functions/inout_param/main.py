def main(req, abc):
    return 'trust me, it is OK!'
