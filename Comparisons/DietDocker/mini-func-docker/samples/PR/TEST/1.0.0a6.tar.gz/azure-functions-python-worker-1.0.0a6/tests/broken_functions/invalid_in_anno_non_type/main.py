def main(req: 123):  # annotations must be types!
    return 'trust me, it is OK!'
