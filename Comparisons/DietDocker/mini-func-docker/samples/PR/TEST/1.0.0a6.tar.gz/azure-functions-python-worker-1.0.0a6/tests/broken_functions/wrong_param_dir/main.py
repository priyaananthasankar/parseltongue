def main(req, foo: int):
    return 'trust me, it is OK!'
