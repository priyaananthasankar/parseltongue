Functions in this directory are purposefully "broken".  They either have
missing information in `function.json`, or invalid signatures, or even
syntax errors.  They are tested in "test_broken_functions.py".
