def main():
    return 'trust me, it is OK!'
