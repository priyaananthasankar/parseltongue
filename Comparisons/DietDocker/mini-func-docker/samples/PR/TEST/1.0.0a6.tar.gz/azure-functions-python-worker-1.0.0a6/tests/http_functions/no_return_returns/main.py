def main(req):
    return 'ABC'
