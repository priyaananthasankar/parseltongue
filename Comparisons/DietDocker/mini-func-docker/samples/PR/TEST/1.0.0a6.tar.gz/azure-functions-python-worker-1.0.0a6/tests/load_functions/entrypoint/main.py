def customentry(req) -> str:
    return __name__
