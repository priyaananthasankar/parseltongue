def main(req, spam):
    return 'trust me, it is OK!'
