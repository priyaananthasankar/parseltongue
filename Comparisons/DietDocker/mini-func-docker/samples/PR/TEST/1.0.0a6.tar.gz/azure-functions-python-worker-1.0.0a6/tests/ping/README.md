This function is used to check the host availability in tests.
Please do not remove.
