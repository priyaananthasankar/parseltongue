def main(req):
    return 'trust me, it is OK!'
