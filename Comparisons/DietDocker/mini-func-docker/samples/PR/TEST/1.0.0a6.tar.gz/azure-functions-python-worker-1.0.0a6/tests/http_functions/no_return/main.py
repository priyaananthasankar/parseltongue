import logging


logger = logging.getLogger('test')


def main(req):
    logger.error('hi')
