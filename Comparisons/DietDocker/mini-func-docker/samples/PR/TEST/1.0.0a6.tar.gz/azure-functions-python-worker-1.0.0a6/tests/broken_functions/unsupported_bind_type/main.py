def main(req, ret):
    return 'trust me, it is OK!'
